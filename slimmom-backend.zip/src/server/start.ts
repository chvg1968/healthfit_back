import Server from "./server";

new Server().start();
